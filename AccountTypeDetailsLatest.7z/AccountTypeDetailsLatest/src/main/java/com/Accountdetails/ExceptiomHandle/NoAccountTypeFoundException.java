package com.Accountdetails.ExceptiomHandle;

public class NoAccountTypeFoundException extends RuntimeException{
	public NoAccountTypeFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}

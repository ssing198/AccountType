package com.Accountdetails.ExceptiomHandle;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler{
	
	
	@ExceptionHandler(Exception.class)
	  public final ResponseEntity<ExceptionResponse> handleAllExceptions(Exception ex, WebRequest request) {
	    ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(), ex.getMessage(),
	        request.getDescription(false));
	    return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	  }

	  @ExceptionHandler(AccountIDNotFound.class)
	  public final ResponseEntity<Object> handleAccountIDNotFoundException(AccountIDNotFound ex) {
		  ErrorDetails errorDetails = new ErrorDetails("400", ex.getMessage());
		    return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
		  }
	  
	  @ExceptionHandler(NoAccountTypeFoundException.class)
	  public final ResponseEntity<Object> handleNoAccountTypeFoundException(NoAccountTypeFoundException ex) {
		  ErrorDetails errorDetails = new ErrorDetails("400", "No Account Type Details of this ID in our Database ");
		    return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
		  }
}

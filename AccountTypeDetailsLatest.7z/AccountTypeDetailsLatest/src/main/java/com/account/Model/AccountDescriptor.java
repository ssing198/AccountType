package com.account.Model;

import org.springframework.stereotype.Component;


public class AccountDescriptor {

	private String AccountId;
	private String AccountType;
	private String DisplayName;
	private String Description;
	private int AccountDescriptionId;
	
	public AccountDescriptor() {
		
	}

	public AccountDescriptor(String accountId, String accountType, String displayName, String description,
			int accountDescriptionId) {
		
		super();
		accountId = this.AccountId;
		AccountType = accountType;
		DisplayName = displayName;
		Description = description;
		AccountDescriptionId = accountDescriptionId;
	}

	public String getAccountId() {
		return AccountId;
	}

	public void setAccountId(String accountId) {
		AccountId = accountId;
	}

	public String getAccountType() {
		return AccountType;
	}

	public void setAccountType(String accountType) {
		AccountType = accountType;
	}

	public String getDisplayName() {
		return DisplayName;
	}

	public void setDisplayName(String displayName) {
		DisplayName = displayName;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public int getAccountDescriptionId() {
		return AccountDescriptionId;
	}

	public void setAccountDescriptionId(int accountDescriptionId) {
		AccountDescriptionId = accountDescriptionId;
	}

}

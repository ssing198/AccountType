package com.account.Model;

public class Account {
	
	DepositAccount dAc;
	LocAccount loca;
	
	public DepositAccount getdAc() {
		return dAc;
	}
	public void setdAc(DepositAccount dAc) {
		this.dAc = dAc;
	}
	
	

	

}

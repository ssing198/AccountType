package com.account.Model;

import java.util.Date;

public class InvestmentAccount {

	private int investmentAccountId;
	private int refAccountId;
	private Date balanceAsOf;
	private int currentValue;
	private String employerName;
	private int allowedCheckWriting;
	private int allowedOptionTrade;
	private String holdings;
	private String openOrders;
	private String contribution;
	private String vesting;
	private String investmentLoans;
	private Double availableCashBalance;
	private int margin;
	private Double marginBalance;
	private Double shortBalance;
	private int rolloverAmount;
	private String brokerId;
	private String planId;

	public InvestmentAccount() {

	}

	public InvestmentAccount(int investmentAccountId, int refAccountId, Date balanceAsOf, int currentValue,
			String employerName, int allowedCheckWriting, int allowedOptionTrade, String holdings, String openOrders,
			String contribution, String vesting, String investmentLoans, Double availableCashBalance, int margin,
			Double marginBalance, Double shortBalance, int rolloverAmount, String brokerId, String planId) {
		super();
		this.investmentAccountId = investmentAccountId;
		this.refAccountId = refAccountId;
		this.balanceAsOf = balanceAsOf;
		this.currentValue = currentValue;
		this.employerName = employerName;
		this.allowedCheckWriting = allowedCheckWriting;
		this.allowedOptionTrade = allowedOptionTrade;
		this.holdings = holdings;
		this.openOrders = openOrders;
		this.contribution = contribution;
		this.vesting = vesting;
		this.investmentLoans = investmentLoans;
		this.availableCashBalance = availableCashBalance;
		this.margin = margin;
		this.marginBalance = marginBalance;
		this.shortBalance = shortBalance;
		this.rolloverAmount = rolloverAmount;
		this.brokerId = brokerId;
		this.planId = planId;
	}

	public int getInvestmentAccountId() {
		return investmentAccountId;
	}

	public void setInvestmentAccountId(int investmentAccountId) {
		this.investmentAccountId = investmentAccountId;
	}

	public int getRefAccountId() {
		return refAccountId;
	}

	public void setRefAccountId(int refAccountId) {
		this.refAccountId = refAccountId;
	}

	public Date getBalanceAsOf() {
		return balanceAsOf;
	}

	public void setBalanceAsOf(Date balanceAsOf) {
		this.balanceAsOf = balanceAsOf;
	}

	public int getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(int currentValue) {
		this.currentValue = currentValue;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public int getAllowedCheckWriting() {
		return allowedCheckWriting;
	}

	public void setAllowedCheckWriting(int allowedCheckWriting) {
		this.allowedCheckWriting = allowedCheckWriting;
	}

	public int getAllowedOptionTrade() {
		return allowedOptionTrade;
	}

	public void setAllowedOptionTrade(int allowedOptionTrade) {
		this.allowedOptionTrade = allowedOptionTrade;
	}

	public String getHoldings() {
		return holdings;
	}

	public void setHoldings(String holdings) {
		this.holdings = holdings;
	}

	public String getOpenOrders() {
		return openOrders;
	}

	public void setOpenOrders(String openOrders) {
		this.openOrders = openOrders;
	}

	public String getContribution() {
		return contribution;
	}

	public void setContribution(String contribution) {
		this.contribution = contribution;
	}

	public String getVesting() {
		return vesting;
	}

	public void setVesting(String vesting) {
		this.vesting = vesting;
	}

	public String getInvestmentLoans() {
		return investmentLoans;
	}

	public void setInvestmentLoans(String investmentLoans) {
		this.investmentLoans = investmentLoans;
	}

	public Double getAvailableCashBalance() {
		return availableCashBalance;
	}

	public void setAvailableCashBalance(Double availableCashBalance) {
		this.availableCashBalance = availableCashBalance;
	}

	public int getMargin() {
		return margin;
	}

	public void setMargin(int margin) {
		this.margin = margin;
	}

	public Double getMarginBalance() {
		return marginBalance;
	}

	public void setMarginBalance(Double marginBalance) {
		this.marginBalance = marginBalance;
	}

	public Double getShortBalance() {
		return shortBalance;
	}

	public void setShortBalance(Double shortBalance) {
		this.shortBalance = shortBalance;
	}

	public int getRolloverAmount() {
		return rolloverAmount;
	}

	public void setRolloverAmount(int rolloverAmount) {
		this.rolloverAmount = rolloverAmount;
	}

	public String getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(String brokerId) {
		this.brokerId = brokerId;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

}

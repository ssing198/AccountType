package com.account.Model;

import java.util.Date;

public class LoanAccount {
	
	
	private int loanAccountId;
	private Date balanceAsOf;
	private int principalBalance;
	private int originalPrincipal;
	private int accountId;
	private int loanTerm;
	private int totalNumberOfPayments;
	private Double nextPaymentAmount;
	private Date nextPaymentDate;
	private Double lastPaymentAmount;
	private Date lastPaymentDate;
	private String paymentFrequency;
	
	public LoanAccount() {
		
	}
	
	public LoanAccount(int loanAccountId, Date balanceAsOf, int principalBalance, int originalPrincipal, int accountId,
			int loanTerm, int totalNumberOfPayments, Double nextPaymentAmount, Date nextPaymentDate,
			Double lastPaymentAmount, Date lastPaymentDate, String paymentFrequency) {
		super();
		this.loanAccountId = loanAccountId;
		this.balanceAsOf = balanceAsOf;
		this.principalBalance = principalBalance;
		this.originalPrincipal = originalPrincipal;
		this.accountId = accountId;
		this.loanTerm = loanTerm;
		this.totalNumberOfPayments = totalNumberOfPayments;
		this.nextPaymentAmount = nextPaymentAmount;
		this.nextPaymentDate = nextPaymentDate;
		this.lastPaymentAmount = lastPaymentAmount;
		this.lastPaymentDate = lastPaymentDate;
		this.paymentFrequency = paymentFrequency;
	}

	public int getLoanAccountId() {
		return loanAccountId;
	}

	public void setLoanAccountId(int loanAccountId) {
		this.loanAccountId = loanAccountId;
	}

	public Date getBalanceAsOf() {
		return balanceAsOf;
	}

	public void setBalanceAsOf(Date balanceAsOf) {
		this.balanceAsOf = balanceAsOf;
	}

	public int getPrincipalBalance() {
		return principalBalance;
	}

	public void setPrincipalBalance(int principalBalance) {
		this.principalBalance = principalBalance;
	}

	public int getOriginalPrincipal() {
		return originalPrincipal;
	}

	public void setOriginalPrincipal(int originalPrincipal) {
		this.originalPrincipal = originalPrincipal;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}

	public int getTotalNumberOfPayments() {
		return totalNumberOfPayments;
	}

	public void setTotalNumberOfPayments(int totalNumberOfPayments) {
		this.totalNumberOfPayments = totalNumberOfPayments;
	}

	public Double getNextPaymentAmount() {
		return nextPaymentAmount;
	}

	public void setNextPaymentAmount(Double nextPaymentAmount) {
		this.nextPaymentAmount = nextPaymentAmount;
	}

	public Date getNextPaymentDate() {
		return nextPaymentDate;
	}

	public void setNextPaymentDate(Date nextPaymentDate) {
		this.nextPaymentDate = nextPaymentDate;
	}

	public Double getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	public void setLastPaymentAmount(Double lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}

	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	public String getPaymentFrequency() {
		return paymentFrequency;
	}

	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}
	
	
	
	
	
}

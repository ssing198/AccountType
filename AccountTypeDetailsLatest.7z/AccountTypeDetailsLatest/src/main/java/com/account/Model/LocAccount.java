package com.account.Model;

import java.util.Date;

public class LocAccount {
	private int locAccountId;
	private int accountId;
	private Date balanceAsOf;
	private int creditLine;
	private int availableCredit;
	private Double nextPaymentAmount;

	private Date nextPaymentDate;
	private int principalBalance;
	private int currentBalance;
	private Double lastPaymentAmount;
	private Date lastPaymentDate;

	public LocAccount() {

	}

	public LocAccount(int locAccountId, int accountId, Date balanceAsOf, int creditLine, int availableCredit,
			Double nextPaymentAmount, Date nextPaymentDate, int principalBalance, int currentBalance,
			Double lastPaymentAmount, Date lastPaymentDate) {
		super();
		this.locAccountId = locAccountId;
		this.accountId = accountId;
		this.balanceAsOf = balanceAsOf;
		this.creditLine = creditLine;
		this.availableCredit = availableCredit;
		this.nextPaymentAmount = nextPaymentAmount;
		this.nextPaymentDate = nextPaymentDate;
		this.principalBalance = principalBalance;
		this.currentBalance = currentBalance;
		this.lastPaymentAmount = lastPaymentAmount;
		this.lastPaymentDate = lastPaymentDate;
	}

	public int getLocAccountId() {
		return locAccountId;
	}

	public void setLocAccountId(int locAccountId) {
		this.locAccountId = locAccountId;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public Date getBalanceAsOf() {
		return balanceAsOf;
	}

	public void setBalanceAsOf(Date balanceAsOf) {
		this.balanceAsOf = balanceAsOf;
	}

	public int getCreditLine() {
		return creditLine;
	}

	public void setCreditLine(int creditLine) {
		this.creditLine = creditLine;
	}

	public int getAvailableCredit() {
		return availableCredit;
	}

	public void setAvailableCredit(int availableCredit) {
		this.availableCredit = availableCredit;
	}

	public Double getNextPaymentAmount() {
		return nextPaymentAmount;
	}

	public void setNextPaymentAmount(Double nextPaymentAmount) {
		this.nextPaymentAmount = nextPaymentAmount;
	}

	public Date getNextPaymentDate() {
		return nextPaymentDate;
	}

	public void setNextPaymentDate(Date nextPaymentDate) {
		this.nextPaymentDate = nextPaymentDate;
	}

	public int getPrincipalBalance() {
		return principalBalance;
	}

	public void setPrincipalBalance(int principalBalance) {
		this.principalBalance = principalBalance;
	}

	public int getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(int currentBalance) {
		this.currentBalance = currentBalance;
	}

	public Double getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	public void setLastPaymentAmount(Double lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}

	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

}

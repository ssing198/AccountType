package com.account.Model;

import java.util.Date;

public class DepositAccount {

	private int RefAccountId;
	private Date BalanceAsOf;
	private int CurrentBalance;
	private int Term;
	private int AvailableBalance;
	private int DepositAccountId;
	private Date MaturityDate;

	public int getRefAccountId() {
		return RefAccountId;
	}

	public void setRefAccountId(int refAccountId) {
		RefAccountId = refAccountId;
	}

	public Date getBalanceAsOf() {
		return BalanceAsOf;
	}

	public void setBalanceAsOf(Date balanceAsOf) {
		BalanceAsOf = balanceAsOf;
	}

	public int getCurrentBalance() {
		return CurrentBalance;
	}

	public void setCurrentBalance(int currentBalance) {
		CurrentBalance = currentBalance;
	}

	public int getTerm() {
		return Term;
	}

	public void setTerm(int term) {
		Term = term;
	}

	public int getAvailableBalance() {
		return AvailableBalance;
	}

	public void setAvailableBalance(int availableBalance) {
		AvailableBalance = availableBalance;
	}

	public int getDepositAccountId() {
		return DepositAccountId;
	}

	public void setDepositAccountId(int depositAccountId) {
		DepositAccountId = depositAccountId;
	}

	public Date getMaturityDate() {
		return MaturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		MaturityDate = maturityDate;
	}

}

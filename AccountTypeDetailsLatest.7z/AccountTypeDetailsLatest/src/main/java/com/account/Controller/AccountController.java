package com.account.Controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Accountdetails.ExceptiomHandle.AccountIDNotFound;
import com.Accountdetails.ExceptiomHandle.CustomizedResponseEntityExceptionHandler;
import com.Accountdetails.ExceptiomHandle.NoAccountTypeFoundException;
import com.account.Model.AccountDescriptor;
import com.account.Model.DepositAccount;
import com.account.Model.InvestmentAccount;
import com.account.Model.LoanAccount;
import com.account.Model.LocAccount;
import com.account.repository.AccountRepository;

@RestController
@RequestMapping("/api/v1")
@RefreshScope
public class AccountController {

	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	AmqpTemplate amqpTemplate;

	@Value("${message:testdata}")
	private String message;

	private static final Logger logger = LogManager.getLogger(AccountController.class);

	@PostMapping("/accounts")
	
	public ResponseEntity<?> getAccountdetail(@Valid @RequestBody AccountDescriptor accountDescriptor) {
		logger.info(message);

		logger.info("getAccountdetail() method has called" + accountDescriptor.getAccountId());

		
		try {
			AccountDescriptor accountDes;
			logger.info("accountDescriptor.getAccountId() " + accountDescriptor.getAccountId());

			if (accountDescriptor.getAccountId() != null) {
				

			} else {

				throw new AccountIDNotFound("AccountId should not be null");
			}

			if (accountDescriptor.getAccountId().length() <= 10) {
				

			} else {

				throw new AccountIDNotFound("AccountId length should be max length 10");
			}

			accountDes = accountRepository.findOne(accountDescriptor.getAccountId());

			

			List<LoanAccount> loanAccount = null;
			List<InvestmentAccount> investmentAccount = null;
			List<DepositAccount> depositAccount = null;
			List<LocAccount> locAccount = null;

			if (null != accountDes.getAccountType()) {

				String accType = accountDes.getAccountType();

				if (accType.equalsIgnoreCase("LOAN")) {
					
					loanAccount = accountRepository.findLoanAccountDetails();
					sendMessageLoanAccount(loanAccount);
					return new ResponseEntity<List<LoanAccount>>(loanAccount, HttpStatus.OK);

				} else if (accType.equalsIgnoreCase("INVESTMENT")) {
					investmentAccount = accountRepository.findInvestmentAccountDetails();
					sendMessageIvestmentAccount(investmentAccount);
					return new ResponseEntity<List<InvestmentAccount>>(investmentAccount, HttpStatus.OK);

				} else if (accType.equalsIgnoreCase("DEPOSIT")) {
					depositAccount = accountRepository.findDepositAccountDetails();
					sendMessageDepositAccount(depositAccount);
					return new ResponseEntity<List<DepositAccount>>(depositAccount, HttpStatus.OK);

				} else if (accType.equalsIgnoreCase("LOC")) {
					locAccount = accountRepository.findLocAccountDetails();
					sendMessageLocAccount(locAccount);
					return new ResponseEntity<List<LocAccount>>(locAccount, HttpStatus.OK);
				} else {

					throw new NoAccountTypeFoundException("NO Account Type Found");
				}

			}
			return null;

		} catch (AccountIDNotFound ex) {
			return new CustomizedResponseEntityExceptionHandler().handleAccountIDNotFoundException(ex);
		} catch (NoAccountTypeFoundException ex) {
			return new CustomizedResponseEntityExceptionHandler().handleNoAccountTypeFoundException(ex);
		}
	}
	
	
	
	
	
	 //sending list of Accounts Type to rabbitmq queqe
	 
	public void sendMessageLoanAccount(List<LoanAccount> accountType) {
		logger.info("sendMessageLoanAccount() method has called for rabbitMQ");
		
		
		amqpTemplate.convertAndSend("account_details", accountType.toString());
	}
	
	public void sendMessageIvestmentAccount(List<InvestmentAccount> accountType) {
		logger.info("sendMessage() method has called for rabbitMQ");
		
		logger.info("Account Type"+accountType);
		amqpTemplate.convertAndSend("account_details", accountType.toString());
	}
	
	
	public void sendMessageDepositAccount(List<DepositAccount> accountType) {
		logger.info("sendMessage() method has called for rabbitMQ");
		
		logger.info("Account Details value"+accountType);
		amqpTemplate.convertAndSend("account_details", accountType.toString());
	}
	
	
	public void sendMessageLocAccount(List<LocAccount> accountType) {
		logger.info("sendMessage() method has called for rabbitMQ");
		
		logger.info("Account Details value"+accountType);
		amqpTemplate.convertAndSend("account_details", accountType.toString());
	}
}

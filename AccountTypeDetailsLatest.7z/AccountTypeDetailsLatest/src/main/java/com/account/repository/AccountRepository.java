package com.account.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.account.Model.Account;
import com.account.Model.AccountDescriptor;
import com.account.Model.DepositAccount;
import com.account.Model.InvestmentAccount;
import com.account.Model.LoanAccount;
import com.account.Model.LocAccount;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

@Repository
public class AccountRepository {

	private final JdbcTemplate jdbcTemplate;

	


	private final RowMapper<AccountDescriptor> rowMapper = (ResultSet rs, int row) -> {
		AccountDescriptor ac = new AccountDescriptor();

		ac.setAccountId(rs.getString("AccountId"));
		ac.setAccountType(rs.getString("AccountType"));
		ac.setDisplayName(rs.getString("DisplayName"));
		ac.setDescription(rs.getString("Description"));
		ac.setAccountDescriptionId(rs.getInt("AccountDescriptorId"));
		return ac;

	};

	private final RowMapper<LoanAccount> loantrowMapper = (ResultSet rs, int row) -> {
		LoanAccount ac = new LoanAccount();

		ac.setLoanAccountId(rs.getInt("LoanAccountId"));
		ac.setBalanceAsOf(rs.getDate("BalanceAsOf"));
		ac.setAccountId(rs.getInt("AccountId"));
		ac.setPrincipalBalance(rs.getInt("PrincipalBalance"));
		ac.setOriginalPrincipal(rs.getInt("OriginalPrincipal"));
		ac.setLoanTerm(rs.getInt("LoanTerm"));
		ac.setTotalNumberOfPayments(rs.getInt("TotalNumberOfPayments"));
		ac.setNextPaymentAmount(rs.getDouble("NextPaymentAmount"));
		ac.setNextPaymentDate(rs.getDate("NextPaymentDate"));
		ac.setLastPaymentAmount(rs.getDouble("LastPaymentAmount"));
		ac.setLastPaymentDate(rs.getDate("LastPaymentDate"));
		ac.setPaymentFrequency(rs.getString("PaymentFrequency"));

		return ac;

	};
	
	private final RowMapper<InvestmentAccount> InvestmentrowMapper = (ResultSet rs, int row) -> {
		InvestmentAccount ac = new InvestmentAccount();

		ac.setInvestmentAccountId(rs.getInt("InvestmentAccountId"));
		ac.setBalanceAsOf(rs.getDate("BalanceAsOf"));
		ac.setRefAccountId(rs.getInt("RefIAccountId"));
		ac.setCurrentValue(rs.getInt("CurrentValue"));
		ac.setEmployerName(rs.getString("EmployerName"));
		ac.setAllowedCheckWriting(rs.getInt("AllowedCheckWriting"));
		ac.setAllowedOptionTrade(rs.getInt("AllowedOptionTrade"));
		ac.setHoldings(rs.getString("Holdings"));
		ac.setOpenOrders(rs.getString("OpenOrders"));
		ac.setContribution("Contribution");
		ac.setVesting(rs.getString("Vesting"));
		ac.setInvestmentLoans(rs.getString("InvestmentLoans"));
		ac.setAvailableCashBalance(rs.getDouble("AvailableCashBalance"));
		ac.setMargin(rs.getInt("Margin"));
		ac.setMarginBalance(rs.getDouble("MarginBalance"));
		ac.setShortBalance(rs.getDouble("ShortBalance"));
		ac.setRolloverAmount(rs.getInt("RolloverAmount"));
		ac.setBrokerId(rs.getString("BrokerId"));
		ac.setPlanId(rs.getString("PlanId"));

		return ac;

	};
	
	private final RowMapper<LocAccount> locAccountrowMapper = (ResultSet rs, int row) -> {
		LocAccount ac = new LocAccount();

		ac.setLocAccountId(rs.getInt("LocAccountId"));
		ac.setBalanceAsOf(rs.getDate("BalanceAsOf"));
		ac.setAccountId(rs.getInt("AccountId"));
		ac.setPrincipalBalance(rs.getInt("PrincipalBalance"));
		ac.setAvailableCredit(rs.getInt("AvailableCredit"));
		ac.setCurrentBalance(rs.getInt("CurrentBalance"));
		ac.setNextPaymentAmount(rs.getDouble("NextPaymentAmount"));
		ac.setNextPaymentDate(rs.getDate("NextPaymentDate"));
		ac.setLastPaymentAmount(rs.getDouble("LastPaymentAmount"));
		ac.setLastPaymentDate(rs.getDate("LastPaymentDate"));
		

		return ac;

	};
	
	private final RowMapper<DepositAccount> depositAccounttrowMapper = (ResultSet rs, int row) -> {
		DepositAccount ac = new DepositAccount();

		ac.setRefAccountId(rs.getInt("RefAccountId"));
		ac.setBalanceAsOf(rs.getDate("BalanceAsOf"));
		ac.setCurrentBalance(rs.getInt("CurrentBalance"));
		ac.setTerm(rs.getInt("Term"));
		ac.setAvailableBalance(rs.getInt("AvailableBalance"));
		ac.setDepositAccountId(rs.getInt("DepositAccountId"));
	    ac.setMaturityDate(rs.getDate("MaturityDate"));
		

		return ac;

	};
	

	@Autowired
	public AccountRepository(JdbcTemplate template) {
		this.jdbcTemplate = template;
	}

	
	public List<DepositAccount> findDepositAccountDetails() {

		String SQL_QUERY_BY_ACCOUNT_TYPE = "select * from depositaccount";
		return this.jdbcTemplate.query(SQL_QUERY_BY_ACCOUNT_TYPE, depositAccounttrowMapper);

	}
	
	
	public List<LoanAccount> findLoanAccountDetails() {

		String SQL_QUERY_BY_ACCOUNT_TYPE = "select * from loanaccount";
		return this.jdbcTemplate.query(SQL_QUERY_BY_ACCOUNT_TYPE, loantrowMapper);

	}
	
	
	public List<LocAccount> findLocAccountDetails() {

		String SQL_QUERY_BY_ACCOUNT_TYPE = "select * from locaccount";
		return this.jdbcTemplate.query(SQL_QUERY_BY_ACCOUNT_TYPE, locAccountrowMapper);

	}
	
	public List<InvestmentAccount> findInvestmentAccountDetails() {

		String SQL_QUERY_BY_ACCOUNT_TYPE = "select * from investmentaccount";
		return this.jdbcTemplate.query(SQL_QUERY_BY_ACCOUNT_TYPE, InvestmentrowMapper);

	}

	public AccountDescriptor findOne(String id) {
		
		String SQL_QUERY_BY_ID = "select * from accountdescriptor where ACCOUNTID='" + id + "'";
		
		return this.jdbcTemplate.queryForObject(SQL_QUERY_BY_ID, rowMapper);
	}

}
